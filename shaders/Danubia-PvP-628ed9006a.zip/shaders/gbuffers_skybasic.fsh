#version 330 compatibility
// Ciel en dégradé : couleur du brouillard à l'horizon, couleur du ciel en haut, halo chaud du côté du soleil.
// Étoiles et bande du lever / coucher : rendu vanilla.
#include "/lib/reglages.glsl"

uniform int renderStage;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform vec3 sunPosition;
uniform mat4 gbufferModelView;
uniform float sunAngle;

in vec4 couleur;
in vec3 posVue;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 sortie;

void main() {
    if (renderStage == MC_RENDER_STAGE_STARS || renderStage == MC_RENDER_STAGE_SUNSET) {
        sortie = couleur;
        return;
    }
    vec3 dir = normalize(posVue);
    float h = dot(dir, normalize(gbufferModelView[1].xyz));
    vec3 c = mix(fogColor, skyColor, smoothstep(0.0, 0.4, h));
    float versSoleil = max(dot(dir, normalize(sunPosition)), 0.0);
    float bas = 1.0 - smoothstep(0.0, 0.45, sin(sunAngle * 6.2831853));
    c += vec3(1.0, 0.55, 0.25) * pow(versSoleil, 6.0) * 0.35 * bas * CHALEUR * 2.0;
    sortie = vec4(c, 1.0);
}

#version 330 compatibility
// L'eau ne fait pas d'ombre (on voit le fond et ce qui nage dedans).
uniform sampler2D gtexture;
in vec2 uv;
in vec4 couleur;
in float estEau;
/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 sortie;
void main() {
    vec4 a = texture(gtexture, uv) * couleur;
    if (a.a < 0.1 || estEau > 0.5) discard;
    sortie = a;
}

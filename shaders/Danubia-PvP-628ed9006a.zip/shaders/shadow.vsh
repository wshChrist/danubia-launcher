#version 330 compatibility
#include "/lib/reglages.glsl"
#include "/lib/distorsion.glsl"
in vec4 mc_Entity;
out vec2 uv;
out vec4 couleur;
out float estEau;
void main() {
    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    couleur = gl_Color;
    estEau = mc_Entity.x == 10.0 ? 1.0 : 0.0;
    gl_Position = ftransform();
    gl_Position.xyz = distordre(gl_Position.xyz);
}

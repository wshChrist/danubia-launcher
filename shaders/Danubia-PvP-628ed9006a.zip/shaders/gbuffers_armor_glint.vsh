#version 330 compatibility
#include "/lib/simple.vsh"

#version 330 compatibility
#define TEXTURE
#include "/lib/reglages.glsl"
#define ALPHA PLUIE
#include "/lib/simple.fsh"

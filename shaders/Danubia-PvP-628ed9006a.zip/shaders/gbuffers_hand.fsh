#version 330 compatibility
#define ENTITES
#define MAIN
#include "/lib/eclaire.fsh"

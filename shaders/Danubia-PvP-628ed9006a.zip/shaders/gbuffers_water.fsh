#version 330 compatibility
#define EAU
#include "/lib/eclaire.fsh"

#version 330 compatibility
#define ALPHA 0.8
#include "/lib/simple.fsh"

#version 330 compatibility
#include "/lib/eclaire.vsh"

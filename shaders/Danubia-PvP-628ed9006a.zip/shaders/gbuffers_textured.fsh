#version 330 compatibility
#define PLAT
#include "/lib/eclaire.fsh"

#version 330 compatibility
out vec4 couleur;
out vec3 posVue;
void main() {
    couleur = gl_Color;
    posVue = (gl_ModelViewMatrix * gl_Vertex).xyz;
    gl_Position = ftransform();
}

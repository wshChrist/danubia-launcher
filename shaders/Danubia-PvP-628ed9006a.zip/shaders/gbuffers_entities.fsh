#version 330 compatibility
#define ENTITES
#include "/lib/eclaire.fsh"

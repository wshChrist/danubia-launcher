#version 330 compatibility
#define TEXTURE
#include "/lib/simple.fsh"

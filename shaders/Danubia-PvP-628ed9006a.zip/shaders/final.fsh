#version 330 compatibility
// Image finale : léger halo des lumières vives, étalonnage, vignette. Ni flou, ni profondeur de champ.
#include "/lib/reglages.glsl"

uniform sampler2D colortex0;
const bool colortex0MipmapEnabled = true;

in vec2 uv;
layout(location = 0) out vec4 sortie;

void main() {
    vec3 c = texture(colortex0, uv).rgb;
    vec3 halo = max(textureLod(colortex0, uv, 3.0).rgb - 0.78, 0.0) * 0.7
              + max(textureLod(colortex0, uv, 5.0).rgb - 0.70, 0.0);
    c += halo * LUEUR * 2.0;

    float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(vec3(l), c, SATURATION);
    c = (c - 0.5) * CONTRASTE + 0.5;
    c *= mix(vec3(1.0), vec3(1.03, 1.0, 0.96), CHALEUR);

    vec2 q = uv - 0.5;
    c *= 1.0 - VIGNETTE * dot(q, q) * 2.0;
    sortie = vec4(clamp(c, 0.0, 1.0), 1.0);
}

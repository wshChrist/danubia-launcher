// Éclairage commun. Choix PvP : l'ombre ne descend jamais sous (1 - FORCE_OMBRES) de la lumière du soleil,
// la nuit garde NUIT_CLAIRE, rien n'est sous LUMIERE_MIN : un candidat reste visible partout.

uniform sampler2DShadow shadowtex0;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform mat4 gbufferModelViewInverse;
uniform vec3 shadowLightPosition;
uniform vec3 fogColor;
uniform float sunAngle;
uniform float rainStrength;
uniform float nightVision;
uniform float far;
uniform int isEyeInWater;

const float TAU = 6.2831853;

// 0 la nuit, 1 le jour (sunAngle : 0 lever, 0,25 midi, 0,5 coucher)
float jour() {
    return smoothstep(-0.06, 0.10, sin(sunAngle * TAU));
}

// Lumière directe reçue : angle avec le soleil × ombre portée
float lumiereDirecte(vec3 posVue, vec3 n) {
    vec3 l = normalize(shadowLightPosition);
    float ndl = clamp(dot(n, l), 0.0, 1.0);
#ifndef OMBRES
    return ndl;
#else
    if (ndl <= 0.0) return 0.0;
    vec4 p = gbufferModelViewInverse * vec4(posVue, 1.0);
    float d = length(p.xyz);
    if (d > shadowDistance) return ndl;
    p.xyz += mat3(gbufferModelViewInverse) * n * (0.03 + d * 0.002);
    vec4 s = shadowProjection * (shadowModelView * p);
    s.xyz = distordre(s.xyz) * 0.5 + 0.5;
    s.z -= 0.0005;
#ifdef FLOU_OMBRES
    float t = 1.0 / float(shadowMapResolution);
    float o = 0.25 * (texture(shadowtex0, s.xyz + vec3(t, t, 0.0)) + texture(shadowtex0, s.xyz + vec3(-t, t, 0.0))
                    + texture(shadowtex0, s.xyz + vec3(t, -t, 0.0)) + texture(shadowtex0, s.xyz + vec3(-t, -t, 0.0)));
#else
    float o = texture(shadowtex0, s.xyz);
#endif
    return ndl * mix(o, 1.0, smoothstep(shadowDistance * 0.8, shadowDistance, d));
#endif
}

// l = lumière des blocs (x) et du ciel (y) entre 0 et 1 ; dl = lumière directe (0 à l'ombre, 1 au soleil)
vec3 eclairer(vec3 albedo, vec2 l, float dl) {
    float j = jour();
    float hauteur = sin(sunAngle * TAU);
    vec3 soleil = mix(vec3(1.0, 0.66, 0.42), vec3(1.0, 0.96, 0.88), smoothstep(0.0, 0.35, hauteur));
    soleil = mix(vec3(1.0), soleil, CHALEUR);
    vec3 teinteOmbre = mix(vec3(1.0), vec3(0.82, 0.88, 1.0), CHALEUR);

    vec3 lumJour = mix(teinteOmbre * (1.0 - FORCE_OMBRES), soleil * 1.06, dl);
    vec3 lumNuit = vec3(0.62, 0.72, 1.0) * (NUIT_CLAIRE + 0.10 * dl);
    float ciel = l.y * l.y * 0.85 + l.y * 0.15;
    vec3 lumCiel = mix(lumNuit, lumJour, j) * ciel * (1.0 - rainStrength * 0.35);

    float b = l.x;
    vec3 lumBlocs = vec3(1.0, 0.74, 0.46) * (b * b * b * 1.05 + b * 0.12) * (1.0 - j * l.y * 0.55);

    vec3 total = max(lumCiel + lumBlocs, vec3(LUMIERE_MIN + nightVision * 0.6));
    return albedo * total;
}

vec3 brouiller(vec3 c, vec3 posVue) {
    vec3 p = (gbufferModelViewInverse * vec4(posVue, 1.0)).xyz;
    float f;
    if (isEyeInWater == 1) f = clamp(length(p) / 48.0, 0.0, 1.0);
    else if (isEyeInWater == 2) f = clamp(length(p) / 2.0, 0.0, 1.0);
    else f = smoothstep(far * BROUILLARD, far, length(p.xz));
    return mix(c, fogColor, f);
}

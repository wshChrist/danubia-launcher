// Réglages du shader Danubia PvP : chaque #define suivi de [valeurs] apparaît dans le menu d'Iris.

#define OMBRES                  // Ombres portées du soleil et de la lune
#define FLOU_OMBRES             // Bord des ombres adouci (4 lectures au lieu d'une)
#define FORCE_OMBRES 0.35       // [0.15 0.25 0.35 0.45 0.55] Écart de lumière entre l'ombre et le soleil
#define NUIT_CLAIRE 0.24        // [0.12 0.18 0.24 0.30 0.36] Lumière du ciel la nuit
#define LUMIERE_MIN 0.08        // [0.04 0.08 0.12 0.16] Plancher de lumière (grottes, intérieurs)
#define SATURATION 1.10         // [0.90 1.00 1.10 1.20 1.30]
#define CONTRASTE 1.06          // [1.00 1.03 1.06 1.10]
#define CHALEUR 0.50            // [0.00 0.25 0.50 0.75 1.00] Soleil doré, ombres bleutées
#define VIGNETTE 0.15           // [0.00 0.10 0.15 0.25]
#define LUEUR 0.25              // [0.00 0.10 0.25 0.40] Halo autour des lumières vives
#define BROUILLARD 0.80         // [0.60 0.70 0.80 0.90] Début du brouillard (part de la distance de rendu)
#define PLUIE 0.55              // [0.25 0.40 0.55 0.75 1.00] Opacité de la pluie et de la neige

const int shadowMapResolution = 1024;   // [512 1024 2048]
const float shadowDistance = 64.0;      // [48.0 64.0 96.0]
const float shadowDistanceRenderMul = 1.0;
const bool shadowHardwareFiltering = true;
const float sunPathRotation = -25.0;

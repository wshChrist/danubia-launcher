// Sommets communs des programmes éclairés.
in vec4 mc_Entity;

out vec2 uv;
out vec2 lm;
out vec4 couleur;
out vec3 posVue;
out vec3 normale;
out float estEau;

void main() {
    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lm = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    couleur = gl_Color;
    posVue = (gl_ModelViewMatrix * gl_Vertex).xyz;
    normale = normalize(gl_NormalMatrix * gl_Normal);
    estEau = mc_Entity.x == 10.0 ? 1.0 : 0.0;
    gl_Position = ftransform();
}

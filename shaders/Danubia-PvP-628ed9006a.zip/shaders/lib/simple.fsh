// Sans éclairage (lueurs, reflets d'enchantement, soleil et lune). TEXTURE = lire la texture ; ALPHA = multiplicateur.
uniform sampler2D gtexture;
uniform float alphaTestRef;
in vec2 uv;
in vec4 couleur;
/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 sortie;
void main() {
#ifdef TEXTURE
    vec4 a = texture(gtexture, uv) * couleur;
#else
    vec4 a = couleur;
#endif
    if (a.a < alphaTestRef) discard;
#ifdef ALPHA
    a.a *= ALPHA;
#endif
    sortie = a;
}

out vec2 uv;
out vec4 couleur;
void main() {
    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    couleur = gl_Color;
    gl_Position = ftransform();
}

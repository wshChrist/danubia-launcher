// Fragments communs. Avant l'include : ENTITES (flash rouge des coups), MAIN (pas d'ombre portée sur la main),
// PLAT (particules : pas de normale), EAU (eau plus transparente).
#include "/lib/reglages.glsl"
#include "/lib/distorsion.glsl"
#include "/lib/lumiere.glsl"

uniform sampler2D gtexture;
uniform float alphaTestRef;
#ifdef ENTITES
uniform vec4 entityColor;
#endif

in vec2 uv;
in vec2 lm;
in vec4 couleur;
in vec3 posVue;
in vec3 normale;
in float estEau;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 sortie;

void main() {
    vec4 a = texture(gtexture, uv) * couleur;
    if (a.a < alphaTestRef) discard;
#ifdef ENTITES
    a.rgb = mix(a.rgb, entityColor.rgb, entityColor.a);
#endif
    vec2 l = clamp((lm * 16.0 - 0.5) / 15.0, 0.0, 1.0);
    vec3 n = normalize(normale);
#if defined(PLAT)
    float dl = 0.7;
#elif defined(MAIN)
    float dl = clamp(dot(n, normalize(shadowLightPosition)), 0.0, 1.0) * 0.6 + 0.4;
#else
    float dl = lumiereDirecte(posVue, n);
#endif
    vec3 c = eclairer(a.rgb, l, dl);
#ifdef EAU
    if (estEau > 0.5) a.a = mix(a.a, 0.45, 0.6);
#endif
    sortie = vec4(brouiller(c, posVue), a.a);
}

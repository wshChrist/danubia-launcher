// Plus de précision près du joueur, moins au loin (même formule dans la passe d'ombre et à la lecture).
vec3 distordre(vec3 p) {
    float f = length(p.xy) * 0.9 + 0.1;
    return vec3(p.xy / f, p.z * 0.25);
}
